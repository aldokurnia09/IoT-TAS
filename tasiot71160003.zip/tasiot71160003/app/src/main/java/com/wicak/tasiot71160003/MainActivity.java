package com.wicak.tasiot71160003;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private TextView textView2;
    private TextView textView4;
    private LinearLayout linearLayout1;
    private String valueAccess;
    private String valueLock;
    private int delaying = 0;
    private int status = 0;

    DatabaseReference database = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("TAS IOT - Aldo/71160003");

        button = (Button) findViewById(R.id.button);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView4 = (TextView) findViewById(R.id.textView4);
        linearLayout1 = (LinearLayout) findViewById(R.id.linearLayout1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lock();
            }
        });

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                valueAccess = dataSnapshot.child("Node1/access").getValue().toString();
                textView2.setTextSize(24);

                if(valueAccess.equals("0")){
                    button.setEnabled(false);
                    linearLayout1.setVisibility(View.INVISIBLE);
                    textView2.setText("NO ACCESS");
                    textView2.setTextColor(Color.parseColor("#FF0000"));
                    textView2.setTypeface(textView2.getTypeface(), Typeface.BOLD);
                }
                else{
                    if(delaying>0) {
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // Do something after 5s = 5000ms
                                button.setEnabled(true);
                                if(status == 1){
                                    button.setText("Lock the Door");
                                }
                                else{
                                    button.setText("Unlock the Door");
                                }
                            }
                        }, 3000);
                    }
                    else{
                        button.setEnabled(true);
                    }
                    linearLayout1.setVisibility(View.VISIBLE);
                    textView2.setText("ACCESS");
                    textView2.setTextColor(Color.parseColor("#00FF00"));
                    textView2.setTypeface(textView2.getTypeface(), Typeface.BOLD);
                }

                valueLock = dataSnapshot.child("Node1/lock").getValue().toString();
                if(valueLock.equals("0")){
                    textView4.setText("LOCKED");
                    textView4.setTextColor(Color.parseColor("#FF0000"));
                    textView4.setTypeface(textView4.getTypeface(), Typeface.BOLD);
                }
                else{
                    textView4.setText("UNLOCKED");
                    textView4.setTextColor(Color.parseColor("#00FF00"));
                    textView4.setTypeface(textView4.getTypeface(), Typeface.BOLD);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void lock(){
        button.setEnabled(false);
        delaying = 1;
        database.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getChildrenCount() > 0) {
                    for (DataSnapshot item : dataSnapshot.getChildren()) {
                        String lock = item.child("lock").getValue().toString();
                        if(lock.equals("0")){
                            database.child("Node1/lock").setValue(1);
                            status = 1;
                        }
                        else{
                            database.child("Node1/lock").setValue(0);
                            status = 0;
                        }
                        button.setText("Please Wait");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}